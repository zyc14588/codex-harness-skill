import assert from "node:assert/strict";
import http, { type IncomingMessage, type Server, type ServerResponse } from "node:http";
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import {
  cleanupTask,
  createControllerPlan,
  inspectMinimalProfileComposition,
  monitorStop,
  startTask,
  taskStatus,
} from "./service.js";
import { runProcess, sha256PathTree, sleep } from "./util.js";

const EXPECTED_HARNESS_COMMIT = process.env.CODEX_HARNESS_FIXTURE_EXPECTED_COMMIT
  ?? "141eb6fef83422698aef7a981029e843e8161534";

async function readBody(request: IncomingMessage): Promise<Record<string, unknown>> {
  const chunks: Buffer[] = [];
  for await (const chunk of request) chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
  return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}") as Record<string, unknown>;
}

function json(response: ServerResponse, status: number, value: unknown): void {
  const body = Buffer.from(JSON.stringify(value));
  response.writeHead(status, { "content-type": "application/json", "content-length": body.length });
  response.end(body);
}

async function listen(server: Server): Promise<number> {
  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  const address = server.address();
  assert.ok(address && typeof address === "object");
  return address.port;
}

async function closeServer(server: Server): Promise<void> {
  if (!server.listening) return;
  await new Promise<void>((resolve) => server.close(() => resolve()));
}

async function git(cwd: string, args: string[]): Promise<string> {
  const result = await runProcess("git", args, { cwd, timeoutMs: 30_000, maxCaptureChars: 100_000 });
  assert.equal(result.code, 0, result.stderr || result.stdout);
  return result.stdout.trim();
}

async function waitTerminal(taskId: string, timeoutMs = 120_000): Promise<Record<string, unknown>> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const current = await taskStatus(taskId) as Record<string, unknown>;
    if (!new Set(["queued", "running"]).has(String(current.status))) return current;
    await sleep(100);
  }
  throw new Error(`dynamic real-profile task did not terminate: ${taskId}`);
}

function toolNames(body: Record<string, unknown>): string[] {
  const tools = Array.isArray(body.tools) ? body.tools : [];
  return tools.flatMap((raw) => {
    if (!raw || typeof raw !== "object" || Array.isArray(raw)) return [];
    const fn = (raw as Record<string, unknown>).function;
    if (!fn || typeof fn !== "object" || Array.isArray(fn)) return [];
    const name = (fn as Record<string, unknown>).name;
    return typeof name === "string" ? [name] : [];
  }).sort();
}

const temp = await mkdtemp(path.join(os.tmpdir(), "codex-harness-dynamic-real-profile-"));
const packageRoot = fileURLToPath(new URL("../../", import.meta.url));
const harnessRoot = path.resolve(process.env.CODEX_HARNESS_FIXTURE_HARNESS_ROOT ?? "/home/zyc14588/deepseek-harness");
const harnessCli = path.join(harnessRoot, "apps", "cli", "lib", "bin.js");
const harnessBuildRoot = path.dirname(harnessCli);
const repo = path.join(temp, "repo");
const stateRoot = path.join(temp, "state");
const dshHome = path.join(temp, "dsh-home");
const configPath = path.join(temp, "config.json");
const taskId = "dynamic-real-profile-task";
const targetPath = "dynamic-profile-probe.txt";
const providerRequests: Array<{ ordinal: number; toolNames: string[]; toolChoice?: unknown; thinkingType?: unknown }> = [];
let providerFailure: string | undefined;
let providerPort = 0;

const provider = http.createServer(async (request, response) => {
  try {
    const url = new URL(request.url ?? "/", "http://127.0.0.1");
    if (!url.pathname.endsWith("/chat/completions")) return json(response, 404, { error: "not found" });
    const body = await readBody(request);
    const ordinal = providerRequests.length + 1;
    const names = toolNames(body);
    providerRequests.push({
      ordinal,
      toolNames: names,
      ...(body.tool_choice === undefined ? {} : { toolChoice: body.tool_choice }),
      ...(body.thinking && typeof body.thinking === "object" && !Array.isArray(body.thinking)
        ? { thinkingType: (body.thinking as Record<string, unknown>).type }
        : {}),
    });
    response.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-cache" });
    if (ordinal === 1) {
      assert.equal(body.tool_choice, "required", "first real Agent mutation request was not forced");
      assert.deepEqual(body.thinking, { type: "disabled" });
      assert.ok(names.includes("bash"), `first provider request omitted bash: ${JSON.stringify(names)}`);
      const durable = JSON.parse(await readFile(path.join(stateRoot, "tasks", taskId, "task.json"), "utf8")) as Record<string, unknown>;
      assert.ok(Number(durable.minimalMutationForceCount ?? 0) >= 1, "force counter was not durable before provider POST");
      const command = `printf 'dynamic-real-profile\\n' > ${targetPath}`;
      response.write(`data: ${JSON.stringify({
        id: "dynamic-provider-1",
        model: "deepseek-v4-flash",
        choices: [{
          index: 0,
          delta: { tool_calls: [{ index: 0, id: "call-dynamic-profile", type: "function", function: { name: "bash", arguments: JSON.stringify({ command }) } }] },
          finish_reason: "tool_calls",
        }],
        usage: { prompt_tokens: 200, completion_tokens: 30, prompt_cache_hit_tokens: 0, prompt_cache_miss_tokens: 200 },
      })}\n\n`);
    } else {
      response.write(`data: ${JSON.stringify({
        id: `dynamic-provider-${ordinal}`,
        model: "deepseek-v4-flash",
        choices: [{ index: 0, delta: { content: "Implemented and verified the exact leased file." }, finish_reason: "stop" }],
        usage: { prompt_tokens: 220, completion_tokens: 12, prompt_cache_hit_tokens: 100, prompt_cache_miss_tokens: 120 },
      })}\n\n`);
    }
    response.write("data: [DONE]\n\n");
    response.end();
  } catch (error) {
    providerFailure = error instanceof Error ? error.message : String(error);
    if (!response.headersSent) json(response, 500, { error: providerFailure });
    else response.destroy(error instanceof Error ? error : new Error(providerFailure));
  }
});

let monitorStarted = false;
try {
  const harnessCommit = await git(harnessRoot, ["rev-parse", "HEAD"]);
  assert.equal(harnessCommit, EXPECTED_HARNESS_COMMIT, "dynamic fixture Harness commit changed");
  const harnessStatus = await git(harnessRoot, ["status", "--porcelain=v1", "--untracked-files=no"]);
  assert.equal(harnessStatus, "", "dynamic fixture requires a clean fixed Harness checkout");
  const harnessBuildSha256 = await sha256PathTree(harnessBuildRoot);

  await mkdir(repo, { recursive: true });
  await writeFile(path.join(repo, "README.md"), "dynamic real managed-profile fixture\n");
  await git(repo, ["init", "-q"]);
  await git(repo, ["config", "user.email", "dynamic-fixture@example.invalid"]);
  await git(repo, ["config", "user.name", "Dynamic Fixture"]);
  await git(repo, ["add", "README.md"]);
  await git(repo, ["commit", "-qm", "fixture"]);

  providerPort = await listen(provider);
  const monitorProbe = http.createServer((_request, response) => response.end());
  const monitorPort = await listen(monitorProbe);
  await closeServer(monitorProbe);
  await writeFile(configPath, `${JSON.stringify({
    schemaVersion: 6,
    harnessRoot,
    harnessCli,
    harnessBuildRoot,
    harnessProfile: "headless",
    harnessMinimalProfile: "codex-minimal-headless",
    dshHome,
    stateRoot,
    allowedRepoRoots: [temp],
    passEnvironment: ["PATH", "HOME", "USER", "LANG", "DEEPSEEK_API_KEY", "DEEPSEEK_BASE_URL", "DSH_MODEL"],
    defaultRuntimeSeconds: 120,
    maxRuntimeSeconds: 300,
    logTailChars: 40_000,
    pinnedHarnessCommit: harnessCommit,
    pinnedHarnessBuildSha256: harnessBuildSha256,
    enforceHarnessPin: true,
    enforceHarnessBuildHash: true,
    requireCleanRepoAtStart: true,
    allowDirtyHarnessCheckout: false,
    controller: {
      requirePlan: true,
      preferMinimalHarness: true,
      splitMemory: { enabled: true, minSamplesForEnforcement: 1 },
    },
    monitor: {
      enabled: true,
      host: "127.0.0.1",
      port: monitorPort,
      autoStart: true,
      charsPerEstimatedToken: 4,
      pricingAsOf: "dynamic mock provider",
      pricing: {},
      currency: { primary: "CNY", showUsd: false, usdToCnyRate: null, fxAsOf: "fixture", fxSource: "fixture" },
    },
    llamaCpp: { enabled: false, fallbackEnabled: false },
  }, null, 2)}\n`, { mode: 0o600 });

  const render = await runProcess("python3", [
    path.join(packageRoot, "scripts", "render-minimal-harness.py"), "install",
    "--template-root", path.join(packageRoot, "harness", "minimal"),
    "--profile-dir", path.join(dshHome, "profiles", "codex-minimal-headless"),
    "--preset-dir", path.join(dshHome, ".agent-presets", "codex-bridge-minimal"),
    "--runtime", packageRoot,
    "--config", configPath,
    "--node", process.execPath,
  ], { timeoutMs: 30_000, maxCaptureChars: 100_000 });
  assert.equal(render.code, 0, render.stderr || render.stdout);

  const composition = await runProcess(process.execPath, [harnessCli, "--profile", "codex-minimal-headless", "--dump-config"], {
    cwd: harnessRoot,
    env: { ...process.env, DSH_HOME: dshHome },
    timeoutMs: 60_000,
    maxCaptureChars: 300_000,
  });
  assert.equal(composition.code, 0, composition.stderr || composition.stdout);
  const compositionInspection = inspectMinimalProfileComposition(composition.stdout, composition.stderr);
  assert.equal(compositionInspection.ok, true, JSON.stringify(compositionInspection));

  process.env.CODEX_HARNESS_CONFIG = configPath;
  process.env.DEEPSEEK_BASE_URL = `http://127.0.0.1:${providerPort}`;
  process.env.DEEPSEEK_API_KEY = "dynamic-mock-key-never-persisted";
  await createControllerPlan({
    repoRoot: repo,
    planId: "dynamic-real-profile-plan",
    leaves: [{
      id: "dynamic-real-profile",
      objective: `Create exactly ${targetPath} containing the line dynamic-real-profile. Use a model-visible mutation tool and do not change any other path.`,
      executor: "harness",
      model: "deepseek-v4-flash",
      complexity: "small",
      harnessMode: "minimal",
      harnessWritePaths: [targetPath],
      acceptanceCriteria: [`${targetPath} contains exactly dynamic-real-profile`],
      verificationCommands: [`test "$(cat ${targetPath})" = dynamic-real-profile`],
      budget: { maxApiCalls: 6, maxInputTokens: 100_000, maxOutputTokens: 10_000, maxCostCny: 5 },
    }],
  });
  await startTask({ planId: "dynamic-real-profile-plan", leafId: "dynamic-real-profile", taskId });
  monitorStarted = true;
  const terminal = await waitTerminal(taskId);
  assert.equal(providerFailure, undefined, providerFailure);
  assert.equal(terminal.status, "completed", JSON.stringify(terminal));
  assert.deepEqual(terminal.changedPaths, [targetPath]);
  assert.ok(Number(terminal.minimalMutationForceCount ?? 0) >= 1, JSON.stringify(terminal));
  assert.ok(Array.isArray(terminal.minimalMutationForcedTools)
    && terminal.minimalMutationForcedTools.some((name) => ["bash", "pwsh", "str_replace_editor"].includes(String(name))));
  assert.ok(Number(terminal.toolProtocolNativeCallCount ?? 0) > 0, JSON.stringify(terminal));
  assert.ok(Array.isArray(terminal.minimalRunnerVisibleTools) && terminal.minimalRunnerVisibleTools.includes("bash"));
  assert.ok(Array.isArray(terminal.minimalRunnerVisibleTools) && terminal.minimalRunnerVisibleTools.includes("str_replace_editor"));
  assert.deepEqual(terminal.minimalRunnerVisibleTools, terminal.minimalAssembledTools);
  const evidence = terminal.minimalRequestEvidence as Array<Record<string, unknown>>;
  const primary = evidence.find((entry) => entry.purpose === "primary_mutation");
  assert.ok(primary, JSON.stringify(evidence));
  assert.deepEqual(primary.adapterToolNames, primary.wireToolNames);
  assert.deepEqual(primary.wireToolNames, primary.proxyParsedToolNames);
  assert.equal(primary.policyApplied, true);
  assert.doesNotMatch(JSON.stringify(evidence), /dynamic-mock-key-never-persisted|Create exactly|dynamic-real-profile\. Use/u);

  const result = {
    result: "PASS",
    fixture: "real-managed-profile-fixed-harness-mock-provider",
    harnessCommit,
    harnessBuildSha256,
    composition: compositionInspection,
    requestCount: providerRequests.length,
    providerRequests,
    task: {
      status: terminal.status,
      changedPaths: terminal.changedPaths,
      minimalMutationForceCount: terminal.minimalMutationForceCount,
      minimalMutationForcedTools: terminal.minimalMutationForcedTools,
      toolProtocolNativeCallCount: terminal.toolProtocolNativeCallCount,
      minimalRunnerVisibleTools: terminal.minimalRunnerVisibleTools,
      minimalAssembledTools: terminal.minimalAssembledTools,
      minimalRequestEvidence: evidence,
    },
  };
  process.stdout.write(`${JSON.stringify(result, null, 2)}\n`);
  await cleanupTask(taskId, true, true);
} finally {
  if (monitorStarted) {
    try { await monitorStop(); } catch { /* best effort fixture cleanup */ }
  }
  await closeServer(provider);
  delete process.env.DEEPSEEK_API_KEY;
  delete process.env.DEEPSEEK_BASE_URL;
  delete process.env.CODEX_HARNESS_CONFIG;
  await rm(temp, { recursive: true, force: true });
}
