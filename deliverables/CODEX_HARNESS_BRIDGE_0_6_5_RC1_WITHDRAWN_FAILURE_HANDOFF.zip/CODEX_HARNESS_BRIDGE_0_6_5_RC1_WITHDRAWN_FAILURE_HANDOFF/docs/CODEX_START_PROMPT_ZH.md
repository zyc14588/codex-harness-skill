# 0.6.5-rc.1 失败后的下一候选修复与验收提示词

`0.6.5-rc.1` 已因真实 DeepSeek smoke 失败而撤回，禁止安装、重跑或以 repair 覆盖。Codex 是唯一总控和最终验收方；未来工作必须创建新候选版本，并从脱敏证据 `evidence/02_REAL_DEEPSEEK_SMOKE_REDACTED.json` 出发。

1. 校验 WITHDRAWN failure-handoff ZIP SHA-256，并在解压后执行 `sha256sum -c MANIFEST_SHA256.txt`；只用于审计与修复，不得安装 rc.1。
2. 记录并保护现有 runtime、state、日志、Harness commit/build hash 和用户主仓库；不得覆盖失败证据。
3. 在新的独立 Git 修复树创建下一候选；不得修改 Harness 源码、已留存 runtime/state 或用户主仓库。
4. 保留 rc.1 已证明有效的独立-ID runner composition、显式请求状态机、五层工具面比较、脱敏 evidence 与 pre-POST force telemetry。
5. 新增 Provider 语义 fixture：前两轮模拟 disabled-thinking 工具响应，diff 后恢复 enabled-thinking；fixture 必须像 DeepSeek 一样拒绝缺少历史 `reasoning_content` 的会话，并证明下一候选不会产生该非法转换。
6. 修复不得伪造 `reasoning_content`。必须选择并证明会话级 thinking 一致性，或在安全边界创建新的会话；同时保持工具强制、预算与 Provider 原生协议。
7. 把这类 Provider semantic/session-transition failure 明确归入基础设施故障；split-memory sample/anomaly/规模/复杂度/Token 建议不得变化。
8. doctor 必须继续确认 stock runner disabled、Bridge runner mounted、session title disabled、minimal preset selected，且无 name-mismatch/skip warning。
9. 运行全部单元测试、deterministic process E2E、stdio MCP、package integrity、真实 managed-profile dynamic fixture，以及新增的严格 reasoning-content Provider fixture。
10. 完成全部离线、动态和 package acceptance 后，才可安装新的候选并创建全新的真实 DeepSeek 单文件 smoke；不得复用 rc.1 的 plan/task ID。
11. 新 smoke 主请求必须显示 `purpose=primary_mutation`、`minimalMutationForceCount>=1`、forced tools 含 core mutation tool，且 native/recovery call count 至少一项大于 0。
12. `changedPaths` 必须精确等于租约。任何 composition、serialization、thinking/session semantic、tool protocol、provider transport、scope、Git、Token 或 no-effect 错误都立即 FAIL 并保留证据，不得 repair 重试真实任务。
13. 确认脱敏 evidence 不含 API key、Authorization、消息正文或工具参数；Codex 再执行逐文件 review、冻结 verification、fingerprint、local commit、cleanup 与 main unchanged 检查。
14. 新 smoke 必须无 failed Provider request、无 Harness stderr、终态 completed，并使 split-memory 写入有效成功样本。
15. 不 cherry-pick、merge、push、tag、发布或自动晋升稳定版。

不得把 rc.1 的 force/native/changed-path 局部 PASS 当成整体 PASS。下一候选只有全部条件同时成立才可报告 PASS；稳定版本仍需要独立发布动作，本提示词不授权。
