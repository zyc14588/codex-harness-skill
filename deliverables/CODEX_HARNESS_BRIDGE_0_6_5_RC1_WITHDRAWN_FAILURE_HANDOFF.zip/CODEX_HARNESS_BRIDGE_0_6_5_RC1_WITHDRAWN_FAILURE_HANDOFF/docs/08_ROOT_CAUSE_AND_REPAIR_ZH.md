# 0.6.4 minimal tool-plane 根因与 0.6.5-rc.1 修复

## 结论

确定根因分类为：

```text
profile_or_preset_composition_failure
```

不是 stale/mixed installation、request purpose ordering、DeepSeek serializer 丢工具或 proxy schema parser mismatch。

## 证据链

1. 已安装 runtime 与回收 runtime 的目录树 SHA-256 均为 `555edb6c760d2c30e7e943755b6519c86d6a160c9e04d0aea504ceb7d95c849f`；逐文件比较无差异。
2. 已安装/回收 profile 树 SHA-256 均为 `9143512bb2d6856675e79a9ac360076fe3db4ec6ac38b292e7cd67db60103a0d`；preset 树均为 `95099e8928f0a1d35413fa94c52667fb2db5267d0f59b6b507743f181db4ba8b`。
3. MCP 实际注册入口为 `/home/zyc14588/.local/share/codex-harness-bridge/0.6.4/bridge/dist/index.js`。失败 monitor 记录的 daemon 也是同一 runtime 的 `bridge/dist/monitor-daemon.js`，PID `126153`；日志报告服务版本 `0.6.4`。
4. 0.6.4 runtime 同时包含 `bridge/src`、`bridge/dist` 和 sourcemap。map 的 `sources` 指回相应 TS 文件；虽然没有内嵌 `sourcesContent`，同一安装树中的 TS 与 map 路径可对应。
5. 0.6.3 baseline 与已安装 0.6.4 有 54 个差异文件、729 行新增、363 行删除；0.6.4 的 title isolation、mutation policy v2 和相关测试确实存在。因此不是“0.6.4 完全没有部署”。
6. 真实 Harness `--dump-config` 对 0.6.4 managed profile 报告：

   ```text
   patch: name mismatch for "headless-runner"
   skipping
   ```

   有效配置仍保留 stock `@deepseek-ai/dsh-headless` runner。原因是 Cordis patch 的 `name` 是身份守卫，不是替换字段；0.6.4 试图在已有 `id=headless-runner` 上修改 `name`，导致整条 patch 被跳过。
7. stock runner 没有执行 Bridge runner 的 preset mount、Agent scoped tool snapshot 或 visible-tool preflight。全局工具又被 minimal profile 禁用，故真实主请求没有 `bash`/`pwsh`/`str_replace_editor`。
8. 代理在无 core tool 时返回 preflight reason；旧 force counter 只在 policy `applied=true` 的分支递增。请求在 Provider POST 前被拒绝，所以观测到 `minimalMutationForceCount=0`、Provider calls/tokens 为 0、无 diff。这与失败任务遥测完全一致。

实际配置固定 Harness commit 为 `141eb6fef83422698aef7a981029e843e8161534`，CLI 构建树 SHA-256 为 `6a294d72c51e6570852acaf73458cda98f555bd53c9c7ff0b49c568e7cf88a38`。交接资料中较旧的 `47f943…` 与真实配置不一致；修复和动态 fixture 使用真实配置的固定值。

## 排除项

- `stale_or_mixed_installation`：runtime/profile/preset 的安装与回收 hash、MCP 路径和 monitor module identity 一致。
- `request_purpose_ordering_failure`：0.6.4 失败发生在 Bridge runner 未挂载之后；不是 auxiliary 抢先。候选版仍以显式 purpose 消除未来顺序猜测。
- `tool_serialization_mismatch`：失败配置中工具在 Agent composition 层就不存在，不是 adapter→wire 丢失。
- `proxy_schema_parser_mismatch`：输入 wire 本身无 core schema；解析器没有把已存在工具漏掉。

## 最小修复

1. 禁用 stock `headless-runner`，以独立 `codex-bridge-headless-runner` ID 插入 Bridge runner；不修改 Harness 源码。
2. runner 在 followup 前记录 preset ID、Agent scoped visible tools、assembled tools，并 arm primary mutation。
3. runner 在 `llm/stream` 观察冻结后的 DeepSeek `GenerateOptions.tools` 与 `purpose`。
4. proxy 依序认领 adapter observation，记录脱敏 wire envelope，并比较 visible=assembled=adapter=wire=proxy-parsed。
5. auxiliary 在 policy 前按显式 purpose bypass；主请求无 diff 时才应用 required-tool policy。
6. force counter、forced tools 和 evidence `policyApplied` 在 Provider POST 前原子持久化并执行 impossible-state invariant。
7. 错误分离为 `minimal_tool_plane_composition`、`minimal_tool_serialization_mismatch`、`tool_protocol`、`provider_transport` 和 `no_effect`。
8. doctor 解析有效 profile 内容并拒绝 runner 缺失、session title 未禁用、preset 未选中或 mismatch/skip warning。

## 安全与治理保持项

输入/输出 Token 仍是唯一模型用量硬门禁；API 次数和费用仍只作参考告警。scope、Git HEAD/index、symlink/gitlink、逐文件审查、冻结验证、fingerprint 和无 diff 门禁均未放宽。Bridge 不自动 merge、push、tag 或发布。
