# 0.6.5-rc.1 真实 DeepSeek smoke

最终状态：`FAIL / CANDIDATE WITHDRAWN`。

## 冻结环境

```text
candidate: 0.6.5-rc.1
source commit: b481c798c64e7566ee359f97480b3f8d794e0954
Harness commit: 141eb6fef83422698aef7a981029e843e8161534
Harness build SHA-256: 6a294d72c51e6570852acaf73458cda98f555bd53c9c7ff0b49c568e7cf88a38
model: deepseek-v4-flash
mode: minimal
plan: rc1-real-deepseek-smoke-plan
task: rc1-real-deepseek-smoke-task
base/main: 05773fb6bee92b6f58f0aae6556b014103eebd24
lease: rc1-real-deepseek-smoke.txt
```

用户明确授权只把隔离 smoke 的固定任务说明与 `README.md` 上下文发送给 DeepSeek。key 由 `$DSH_HOME/.credentials.yaml` 的凭据提供方解析；Codex 未读取、打印或写入 key。

## 已证明的原修复点

- runner visible、assembled、DeepSeek adapter input、wire、proxy parsed 五层工具列表三次均完全一致；
- 列表为 `bash`、`mcp__bridge__capability_catalog`、`mcp__bridge__capability_enable`、`str_replace_editor`；
- `minimalMutationForceCount=2`；
- forced tools 为 `bash`、`str_replace_editor`；
- native call count 为 2，native tool 为 `bash`；
- pre-POST policy evidence 已持久化；
- 唯一变更为租约内 `rc1-real-deepseek-smoke.txt`，内容与要求完全相同。

## 终止失败

前两个无 diff 的 mutation 请求应用 `minimal-flash-explicit-purpose-v3`：工具面收窄为 core mutation tools、`tool_choice=required`、`thinking=disabled`。文件出现后，第三个 follow-up 不再应用该策略，恢复 adapter 的 `thinking=enabled` 请求。

这次转换把先前 disabled-thinking 的 assistant/tool 历史带入 enabled-thinking 请求，但历史 assistant 消息没有 DeepSeek 要求的 `reasoning_content`。Provider 返回：

```text
INVALID_REQUEST: The `reasoning_content` in the thinking mode must be passed back to the API.
```

Harness 退出码为 1，任务终态 `failed`。用量为 3 个 API 请求（2 completed / 1 failed）、3551 input tokens、239 output tokens、0.00308984 CNY 本地估算。

## 硬门禁判定

| 门禁 | 结果 |
|---|---|
| force count / core forced tools | PASS |
| native 或 recovery call | PASS（native=2） |
| changed paths 精确等于租约 | PASS |
| 逐文件只读取证 | 完成，但不构成 approval |
| controller review approved | FAIL / 未执行 |
| verification | FAIL / 未执行 |
| 三 fingerprint 一致 | FAIL / 不存在 |
| smoke local commit | FAIL / 未创建 |
| worktree/branch cleanup | PASS |
| main unchanged | PASS |
| split-memory valid success | FAIL；记录为 anomaly |
| real DeepSeek/Harness smoke | **FAIL** |

split-memory revision 1 的 `successCount=0`、`anomalyCount=1`，并把 Provider 语义转换失败归为 `task_shape`，推荐 scale 从 1 降为 0.65；下一候选还必须把此类 failure 归入不影响 split advice 的基础设施类别。

失败 worktree 与任务分支已删除；smoke 主分支仍为冻结 base 且干净。候选 MCP、skill、managed profile/preset 与 monitor 已撤回；versioned runtime、config、state、日志和证据保留。不得重跑或 repair 本候选来覆盖此次失败。
