# 0.6.5-rc.1 测试报告

报告状态：离线与 package acceptance 全部 PASS；真实 DeepSeek smoke **FAIL**；候选 **WITHDRAWN**。

## 已通过

- TypeScript 5.8.3 strict build：PASS。
- 67 项单元测试：67 PASS / 0 FAIL。
- 新增状态机门禁：auxiliary-before-policy、composition attribution、serialization mismatch、pre-POST force counter、impossible invariant、证据脱敏：PASS。
- 新增 split-memory composition/serialization 基础设施隔离：PASS；sample/anomaly 均不增长，规模和 Token 建议不变。
- profile semantic doctor：修复组合 PASS；0.6.4 name-mismatch/skip fixture 正确 FAIL。
- deterministic controller/monitor/Harness/llama.cpp process E2E：PASS。
- dynamic real managed-profile fixture：PASS。使用真实 managed profile/preset、固定 Harness commit、真实 Agent/assembly/DeepSeek serializer/Bridge proxy 和 loopback mock Provider；不是直接构造 proxy body。
- bundled `codex-harness` skill quick validation：PASS。
- package acceptance：PASS。覆盖 fresh install、installed acceptance、schema 3→4→5→6 migration、同版/跨版回滚、卸载、manifest/schema 与源码卫生。

## 动态 fixture 核心结果

```text
Harness commit: 141eb6fef83422698aef7a981029e843e8161534
Harness build:  6a294d72c51e6570852acaf73458cda98f555bd53c9c7ff0b49c568e7cf88a38
effective composition: PASS
request count: 2
force count: 1
forced tools: bash, str_replace_editor
native call count: 1
changed paths: dynamic-profile-probe.txt
```

首请求在 runner visible、assembled、DeepSeek adapter input、wire 和 proxy parsed 五层均为：

```text
bash
mcp__bridge__capability_catalog
mcp__bridge__capability_enable
str_replace_editor
```

代理在确认一致后向 mock Provider 转发 `bash`、`str_replace_editor`，设置 `tool_choice=required` 和 `thinking=disabled`。第二次请求在真实 diff 已出现后恢复完整 catalog 和 thinking。

完整脱敏证据见 `evidence/01_DYNAMIC_PROFILE_FIXTURE_REDACTED.json`。

## Package acceptance 核心结果

```text
result: PASS
version: 0.6.5-rc.1
fresh install: PASS
installed acceptance: PASS
schema 3→4→5→6 migration: PASS
same-version rollback: PASS
cross-version rollback: PASS
uninstall: PASS
```

## 真实 smoke 终局

真实 `deepseek-v4-flash` minimal Harness 单文件任务只运行一次并终态失败：

```text
task: rc1-real-deepseek-smoke-task
status: failed
exit code: 1
provider error: INVALID_REQUEST
message: The reasoning_content in the thinking mode must be passed back to the API.
minimalMutationForceCount: 2
minimalMutationForcedTools: bash, str_replace_editor
native call count: 2
changed paths: rc1-real-deepseek-smoke.txt
```

前两次请求在无 diff 时被策略改为 `thinking=disabled` 并强制工具；第二次原生 `bash` 调用产生了精确租约内文件。第三次请求已观察到 diff，策略恢复原始 `thinking=enabled`，但历史 assistant/tool 会话来自 disabled-thinking 响应，缺少 DeepSeek 要求回传的 `reasoning_content`，Provider 拒绝请求，Harness 以 1 退出。

因此没有 review approval、verification、fingerprint、smoke commit 或 split-memory success sample。失败 worktree/branch 已清理，main 不变；split-memory 实际写入 1 个 anomaly，并错误归因为 `task_shape`，把推荐 scale 从 1 降为 0.65。这也是下一候选必须修正的基础设施归因问题。

完整脱敏证据见 `evidence/02_REAL_DEEPSEEK_SMOKE_REDACTED.json`。本候选不得安装或用于 controlled use；mock PASS 不能覆盖本次真实 Provider FAIL。
