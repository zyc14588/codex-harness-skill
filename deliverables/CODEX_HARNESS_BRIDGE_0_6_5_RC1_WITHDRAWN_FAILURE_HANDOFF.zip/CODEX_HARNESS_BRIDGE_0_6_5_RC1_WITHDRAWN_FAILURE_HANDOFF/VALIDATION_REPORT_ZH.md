# 0.6.5-rc.1 候选验证报告

## 当前判定

```text
CANDIDATE VERSION: 0.6.5-rc.1
ROOT CAUSE: profile_or_preset_composition_failure
SOURCE/UNIT/DYNAMIC FIXTURE: PASS
DETERMINISTIC PROCESS E2E: PASS
PACKAGE ACCEPTANCE: PASS
REAL DEEPSEEK SMOKE: FAIL
OVERALL: FAILED / WITHDRAWN
CONTROLLED USE: NOT ALLOWED
```

本报告明确禁止 controlled use，不代表稳定版发布。R6.0–R6.5-rc.1 均为 FAILED/WITHDRAWN；离线、mock 或 package PASS 不能覆盖真实 Provider FAIL。

## 已完成证据

- 精确回收已安装 0.6.4，并确认 runtime/profile/preset 与实际安装 hash 一致。
- MCP 与 monitor module identity 均指向真实 0.6.4 runtime。
- 证明 0.6.4 代码变化存在，排除完全 stale installation。
- 使用真实 Harness effective dump 复现 `headless-runner` name mismatch/skip。
- 在独立 Git 修复树实现独立-ID runner composition、显式请求状态机、五层工具面比较、脱敏 evidence、pre-POST force telemetry 和新错误归因。
- 未修改 Harness 源码、已安装 0.6.4 或用户主项目仓库。
- TypeScript strict build PASS。
- 67/67 单元测试 PASS。
- deterministic process E2E PASS。
- fixed Harness commit + real managed profile/preset + mock Provider 动态全链 fixture PASS。
- bundled skill quick validation PASS。
- package acceptance PASS：fresh/installed acceptance、schema 3→4→5→6 migration、同版与跨版 rollback、uninstall、manifest/schema/source hygiene 全部通过。

## 动态全链结果

Harness commit：`141eb6fef83422698aef7a981029e843e8161534`。

Harness CLI build SHA-256：`6a294d72c51e6570852acaf73458cda98f555bd53c9c7ff0b49c568e7cf88a38`。

首个真实 Agent mutation request 在 runner visible、assembled、DeepSeek adapter、wire 与 proxy parsed 五层均含：

```text
bash
mcp__bridge__capability_catalog
mcp__bridge__capability_enable
str_replace_editor
```

代理确认一致后向 mock Provider 发送 `bash` 与 `str_replace_editor`，设置 `tool_choice=required`、`thinking=disabled`。结果为 force count 1、native call count 1、唯一变更 `dynamic-profile-probe.txt`。详情见 `evidence/01_DYNAMIC_PROFILE_FIXTURE_REDACTED.json`。

## 真实 Provider 失败

候选安装后只执行了一次授权的真实 `deepseek-v4-flash` 单文件 smoke。五层工具面一致、force count 为 2、原生调用为 2，唯一文件也按租约生成；但第三次 follow-up 从策略强制的 disabled-thinking 阶段恢复 enabled-thinking 后，DeepSeek 要求回传先前 assistant 的 `reasoning_content`，请求以 `INVALID_REQUEST` 被拒，Harness 退出码为 1。

这意味着以下硬条件没有成立：

1. `controller_review_task=approved`：未执行；
2. verification：未执行；
3. reviewed/current/verified fingerprint：不存在；
4. smoke local commit：未创建；
5. split-memory valid success sample：没有，实际为 anomaly；
6. 真实 DeepSeek/Harness smoke PASS：未成立。

失败 worktree/branch 已清理，main HEAD/working tree 不变。活动候选集成已撤回：MCP、skill、managed profile/preset 已移除，monitor 已停止；runtime、config、state、日志和证据保留。不得 repair 或重跑本候选来覆盖失败，稳定版 `0.6.5` 不得发布。
