# Codex ↔ DeepSeek Harness Bridge 0.6.5-rc.1

版本：`0.6.5-rc.1`（**FAILED / WITHDRAWN**）。

> **禁止安装或用于 controlled use。** 真实 DeepSeek smoke 在完成租约内文件写入后，以 `INVALID_REQUEST` 终止：从 Bridge 强制的 `thinking=disabled` mutation 阶段恢复到原始 `thinking=enabled` follow-up 时，历史 assistant 消息没有 Provider 要求的 `reasoning_content`。候选已撤回，活动 MCP、skill、managed profile/preset 与 monitor 均已移除；这里只保留完整源码和脱敏失败证据供下一候选修复。

本地 MCP Bridge 让 Codex 直接规划、委派、监控、审查并验证 DeepSeek Harness 与 llama.cpp 叶子任务。本候选版保留并行极简 Harness、渐进式工具披露、自适应拆分记忆、人民币监控和 llama.cpp 路由，并修复已安装 0.6.4 中 managed profile 实际未挂载 Bridge runner 的发布阻断故障。

## 0.6.5-rc.1 发布阻断修复

真实 0.6.4 有效配置转储报告：Cordis patch 试图在 `id=headless-runner` 上把 `name` 从 `@deepseek-ai/dsh-headless` 改为 `./bridge-headless-runner.mjs`。`name` 是身份守卫而不是可替换字段，Harness 因 name mismatch 跳过整条 patch。结果仍运行 stock runner；Bridge preset、scoped tool snapshot 和 custom followup 路径都未执行，首个 mutation 请求以空工具面到达代理，并在 force counter 递增前失败。

候选版采用以下最小修复：

1. **正确组合 runner**：禁用 stock `headless-runner`，再以独立 ID 插入 Bridge runner；doctor 解析有效转储并拒绝 mismatch/skip 警告。
2. **显式请求状态机**：runner 记录 Agent scoped tools 与 assembled tools，并在 `followup()` 前 arm 主施工请求；`llm/stream` 记录 DeepSeek adapter 输入和显式 auxiliary purpose。
3. **逐层一致性门禁**：代理按序比较 visible、assembled、adapter、wire 和 proxy-parsed 工具名；缺失 runner 工具归因 `minimal_tool_plane_composition`，序列化链丢失归因 `minimal_tool_serialization_mismatch`。
4. **不再猜请求用途**：标题、compaction 和 pre-arm 请求在 policy 前按 runner 记录的 purpose 隔离；代理不读取提示正文来猜 auxiliary。
5. **脱敏证据与先写遥测**：只保存用途、序号、endpoint、字段名、工具名/数量、roles、max token、thinking 类型和合同标记；force counter 与 `policyApplied` 在 Provider POST 前原子持久化。
6. **既有硬门禁保持不变**：有写租约的施工叶子无 diff 时失败；工具协议、工具面、传输及 no-effect 基础设施事件不改变拆分建议。

R6.0–R6.5-rc.1 均为 FAILED/WITHDRAWN。强制策略或模型摘要不是成功证据；最终仍只接受租约内 Git diff、逐文件审查、冻结验证和一致 fingerprint。原始 managed-runner 组合故障已被真实五层工具证据证明修复，但 thinking-mode 会话转换形成新的发布阻断。详情见 `docs/10_REAL_DEEPSEEK_SMOKE_ZH.md`。

## 核心原则

```text
Codex = 唯一总控、任务拆分者、审查者和最终验收者
Harness / llama.cpp = 受合同约束的叶子执行器
输入 Token + 输出 Token = 唯一模型用量硬门禁
API 调用次数 + 金额 = 参考告警，不中止任务
```

Bridge 不自动 merge、push 或发布。每个产生变更的叶子仍须经过：

```text
collect → 逐文件读取 → controller_review_task → verify → fingerprint → commit
```

## 自适应拆分记忆

Codex 在创建计划前调用 `controller_split_advice`。Bridge 按仓库、`taskFamily`、executor/model、Harness 模式和任务模式隔离历史。计划冻结 `splitDecision`，记录：

- 记忆 schema 与 revision；
- 有效样本及被忽略的旧 schema 样本；
- 推荐叶子规模和复杂度；
- 推荐输入/输出 Token；
- Codex 最终选择与覆盖理由。

执行、审查、验证和 finalization 分阶段写入记忆，相同 `taskId:stage` 只记录一次。Token 超限、timeout、scope violation、repair、review rejection 和 verification failure 会缩小后续任务；稳定低占用成功可以保守扩大。基础设施异常仅作为运维证据，不参与任务形状学习。

## 模型与拆分策略

| 路径 | 复杂度 | 推荐模式 | 用量门禁 |
|---|---|---|---|
| Harness + `deepseek-v4-pro` | `trivial` / `small` / `medium` / `large` | 优先 `minimal` | 冻结的 input/output Token 硬门禁；Pro complex 不受普通 operator ceiling 限制 |
| Harness + `deepseek-v4-flash` | `trivial` / `small` / `medium` | 优先 `minimal` | input/output Token 硬门禁 |
| llama.cpp | `trivial` / `small` | 结构化完整文件输出 | input/output Token 硬门禁；异常可受控回退 Flash |

`ceilingPolicy=unbounded` 仅表示 Pro complex 不受普通叶子的 operator maximum 约束；每个复杂叶子仍必须冻结有限的 `maxInputTokens` 与 `maxOutputTokens`。

## 并行极简 Harness

同一计划可同时运行多个 Harness worker，前提是依赖已满足、写租约互斥、base commit 相同，并且未超过全局/单仓库并发限制。每个 worker 使用独立 worktree、分支和 budget group。

安装器事务式安装：

```text
$DSH_HOME/profiles/codex-minimal-headless
$DSH_HOME/.agent-presets/codex-bridge-minimal
```

极简 Agent 初始只获得持久 Shell、编辑器和渐进式能力控制工具。只读能力按合同逐步启用，避免把无关工具 Schema 永久放入请求前缀。

## Web Dashboard

默认地址：`http://127.0.0.1:43127`。

- **任务**：活动任务、并行组、依赖、模式、Token、split decision、协议恢复、原生工具调用证据和基础设施异常；
- **费用**：input/output Token 门禁、API/金额参考告警、人民币实时估算、人工对账；
- **本地模型**：自定义 `llama-server` / `llama-cli`、启动参数、启停、自动路由和 Flash fallback；
- **拆分记忆**：有效样本、异常率、基础设施故障、建议规模、复杂度及 Token 门禁。

人民币为默认展示货币，美元默认隐藏；费用为本地配置价格估算，不是供应商账单。

## 撤回状态

本源码树保留安装器只为离线审计和未来修复，不构成安装授权。不要运行 `scripts/install.sh`。真实失败后执行的撤回已：

- 移除 `codex_harness` MCP 注册；
- 移除 controller skill；
- 移除 Bridge-managed minimal profile/preset；
- 停止 monitor；
- 保留版本化 runtime、config、state、日志和脱敏证据。

安装器验证包 manifest、Harness provenance、极简 profile/preset、67 项单元测试、Markdown/DSML/原生工具调用全进程 E2E、stdio MCP、monitor、Codex 注册和事务回滚；候选发布门禁另执行固定 Harness commit 的真实 managed-profile mock-provider fixture。

详细协议见 `docs/`；最终失败判定见 `VALIDATION_REPORT_ZH.md`。后续候选必须先修复并动态验证 thinking-mode 会话一致性，再执行一次新的真实 smoke；不得重跑本候选来覆盖失败。
