import assert from "node:assert/strict";
import http from "node:http";
import { chmod, copyFile, mkdir, mkdtemp, readFile, rm, stat, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { loadConfig } from "./config.js";
import {
  cleanupTask,
  collectTask,
  commitTask,
  createControllerPlan,
  finalizeControllerPlan,
  monitorStop,
  readChangedFile,
  reviewTask,
  startTask,
  taskStatus,
  verifyTask,
} from "./service.js";
import { loadTask } from "./store.js";
import type { TaskRecord } from "./types.js";
import { runProcess, sha256PathTree, sleep } from "./util.js";

type Payload = Record<string, unknown>;

function payload(value: unknown): Payload {
  assert.ok(value && typeof value === "object" && !Array.isArray(value));
  return value as Payload;
}

async function git(cwd: string, args: string[]): Promise<string> {
  const result = await runProcess("git", args, { cwd, timeoutMs: 30_000, maxCaptureChars: 200_000 });
  assert.equal(result.code, 0, result.stderr || result.stdout);
  return result.stdout.trim();
}

async function reserveLoopbackPort(): Promise<number> {
  const server = http.createServer((_request, response) => response.end());
  await new Promise<void>((resolve, reject) => {
    server.once("error", reject);
    server.listen(0, "127.0.0.1", resolve);
  });
  const address = server.address();
  assert.ok(address && typeof address === "object");
  const port = address.port;
  await new Promise<void>((resolve, reject) => server.close((error) => error ? reject(error) : resolve()));
  return port;
}

async function waitTerminal(taskId: string, timeoutMs = 600_000): Promise<Payload> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const current = payload(await taskStatus(taskId));
    if (!new Set(["queued", "running"]).has(String(current.status))) return current;
    await sleep(250);
  }
  throw new Error(`real Provider task did not terminate within ${timeoutMs}ms: ${taskId}`);
}

async function waitProcessesStopped(taskId: string, timeoutMs = 30_000): Promise<void> {
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const current = payload(await taskStatus(taskId));
    if (current.workerAlive !== true && current.harnessAlive !== true) return;
    await sleep(100);
  }
  throw new Error(`real Provider task processes did not stop: ${taskId}`);
}

function safeTaskEvidence(task: TaskRecord): Payload {
  return {
    id: task.id,
    model: task.model,
    status: task.status,
    exitCode: task.exitCode,
    changedPaths: task.changedPaths,
    infrastructureFailureKind: task.infrastructureFailureKind,
    infrastructureFailureDetails: task.infrastructureFailureDetails,
    executionAttempts: task.executionAttempts,
    providerRequestOrdinal: task.providerRequestOrdinal ?? 0,
    thinkingRequestEvidence: task.thinkingRequestEvidence ?? [],
    reasoningReplayRequirements: task.reasoningReplayRequirements ?? [],
    minimalMutationForceCount: task.minimalMutationForceCount ?? 0,
    minimalMutationForcedTools: task.minimalMutationForcedTools ?? [],
    toolProtocolNativeCallCount: task.toolProtocolNativeCallCount ?? 0,
    toolProtocolNativeTools: task.toolProtocolNativeTools ?? [],
    toolProtocolRecoveryCount: task.toolProtocolRecoveryCount ?? 0,
    toolProtocolRecoveredTools: task.toolProtocolRecoveredTools ?? [],
    minimalRequestEvidence: task.minimalRequestEvidence ?? [],
    reviewDecision: task.reviewDecision,
    reviewedPaths: task.reviewedPaths,
    reviewedFingerprint: task.reviewedFingerprint,
    verificationPassed: task.verificationPassed,
    verifiedFingerprint: task.verifiedFingerprint,
    bridgeCommit: task.bridgeCommit,
    worktreeRemoved: task.worktreeRemoved ?? false,
    branchDeleted: task.branchDeleted ?? false,
  };
}

interface LeafSpec {
  planId: string;
  leafId: string;
  taskId: string;
  model: "deepseek-v4-flash" | "deepseek-v4-pro";
  targetPath: string;
  expectedThinking: "disabled" | "enabled";
  minimumRequests: number;
  minimumToolCalls: number;
}

async function runLeaf(repo: string, expectedContent: string, spec: LeafSpec): Promise<Payload> {
  const objective = [
    `Create exactly ${spec.targetPath} as a byte-for-byte copy of README.md and change no other path.`,
    "The README content is intentionally not included in this prompt, so obtain it with a real tool.",
    "Mandatory sequence within this one attempt:",
    "1. Use exactly one bash tool call to read README.md; do not write in that call.",
    `2. After that tool result, use a separate bash tool call to create ${spec.targetPath}; do not verify in that call.`,
    `3. After that tool result, use a separate bash tool call to run cmp -s README.md ${spec.targetPath} and git diff --check; do not combine this with step 2.`,
    "4. Only after the third tool result, return a concise final response.",
    "Do not combine steps, do not skip the verification tool call, and do not create commits.",
  ].join("\n");
  await createControllerPlan({
    repoRoot: repo,
    planId: spec.planId,
    leaves: [{
      id: spec.leafId,
      objective,
      executor: "harness",
      model: spec.model,
      complexity: spec.model === "deepseek-v4-pro" ? "large" : "small",
      harnessMode: "minimal",
      taskFamily: `real-provider-${spec.model}-multiturn-v1`,
      harnessWritePaths: [spec.targetPath],
      contextFiles: [],
      acceptanceCriteria: [
        `Only ${spec.targetPath} changes`,
        `${spec.targetPath} is byte-for-byte identical to README.md`,
        `At least ${spec.minimumRequests} real Provider requests occur in one immutable attempt`,
        `At least ${spec.minimumToolCalls} real tool calls occur`,
      ],
      verificationCommands: [
        `test -f ${spec.targetPath}`,
        `cmp -s README.md ${spec.targetPath}`,
        "git diff --check",
      ],
      budget: { maxApiCalls: 8, maxInputTokens: 250_000, maxOutputTokens: 24_000, maxCostCny: 20 },
      runtimeSeconds: 600,
    }],
  });
  await startTask({ planId: spec.planId, leafId: spec.leafId, taskId: spec.taskId });
  const terminal = await waitTerminal(spec.taskId);
  const config = await loadConfig();
  let task = await loadTask(config, spec.taskId);
  if (terminal.status !== "completed") {
    throw new Error(`real Provider ${spec.model} task failed: ${JSON.stringify(safeTaskEvidence(task))}`);
  }
  assert.equal(task.infrastructureFailureKind, undefined, JSON.stringify(safeTaskEvidence(task)));
  assert.deepEqual(task.changedPaths, [spec.targetPath]);
  assert.equal(task.executionAttempts?.length, 1);
  const attempt = task.executionAttempts?.[0];
  assert.ok(attempt?.id);
  assert.equal(attempt.model, spec.model);
  assert.equal(attempt.thinkingPolicy?.thinkingType, spec.expectedThinking);
  assert.ok((task.providerRequestOrdinal ?? 0) >= spec.minimumRequests, JSON.stringify(safeTaskEvidence(task)));
  const requestEvidence = task.thinkingRequestEvidence ?? [];
  assert.equal(requestEvidence.length, task.providerRequestOrdinal);
  assert.ok(requestEvidence.every((entry) => entry.attemptId === attempt.id));
  assert.ok(requestEvidence.every((entry) => entry.thinkingType === spec.expectedThinking));
  if (spec.expectedThinking === "disabled") {
    assert.ok(requestEvidence.every((entry) => entry.reasoningEffort === undefined));
    assert.ok((task.minimalRequestEvidence ?? []).every((entry) => entry.providerThinkingType === "disabled"));
  } else {
    assert.ok(requestEvidence.every((entry) => entry.reasoningEffort === "high" && !entry.toolChoicePresent));
    const requirements = task.reasoningReplayRequirements ?? [];
    assert.ok(requirements.length > 0, "real Pro tool-call response produced no reasoning replay requirement");
    assert.ok(requirements.every((entry) => entry.reasoningUtf8Bytes > 0 && /^[0-9a-f]{64}$/u.test(entry.reasoningSha256)));
    assert.ok(requirements.every((entry) => entry.replayCount > 0), JSON.stringify(requirements));
  }
  const toolCalls = (task.toolProtocolNativeCallCount ?? 0) + (task.toolProtocolRecoveryCount ?? 0);
  assert.ok(toolCalls >= spec.minimumToolCalls, JSON.stringify(safeTaskEvidence(task)));

  await waitProcessesStopped(spec.taskId);
  const collected = payload(await collectTask(spec.taskId, true, 200_000));
  assert.deepEqual(collected.changedPaths, [spec.targetPath]);
  assert.deepEqual(collected.outOfScopePaths, []);
  assert.deepEqual(collected.unsafeSymlinkPaths, []);
  assert.deepEqual(collected.unsafeGitlinkPaths, []);
  assert.deepEqual(collected.stagedPaths, []);
  const changedFile = payload(await readChangedFile(spec.taskId, spec.targetPath));
  assert.equal(changedFile.content, expectedContent);
  const review = payload(await reviewTask(
    spec.taskId,
    "approved",
    [spec.targetPath],
    `Codex read the complete ${spec.targetPath}, compared it byte-for-byte with README.md, and approved the exact leased change.`,
  ));
  assert.match(String(review.reviewedFingerprint), /^[0-9a-f]{64}$/u);
  const verification = payload(await verifyTask(spec.taskId, undefined, 60));
  assert.equal(verification.passed, true, JSON.stringify(verification));
  assert.equal(verification.reviewedFingerprint, verification.verifiedFingerprint);
  const afterVerification = payload(await collectTask(spec.taskId, false, 0));
  assert.equal(afterVerification.reviewedFingerprint, afterVerification.currentFingerprint);
  assert.equal(afterVerification.currentFingerprint, afterVerification.verifiedFingerprint);
  const committed = payload(await commitTask(spec.taskId, `test(smoke): accept real ${spec.model} multi-turn leaf`));
  assert.match(String(committed.commit), /^[0-9a-f]{40,64}$/u);
  assert.equal(committed.reviewedFingerprint, committed.currentFingerprint);
  assert.equal(committed.currentFingerprint, committed.verifiedFingerprint);
  await finalizeControllerPlan(spec.planId, `Real ${spec.model} multi-turn Provider smoke reviewed, verified, fingerprint-stable, and locally committed.`);
  await cleanupTask(spec.taskId, true, true);
  task = await loadTask(config, spec.taskId);
  assert.equal(task.worktreeRemoved, true);
  assert.equal(task.branchDeleted, true);
  return {
    ...safeTaskEvidence(task),
    requestCount: task.providerRequestOrdinal,
    toolCallCount: toolCalls,
    reviewedFingerprint: afterVerification.reviewedFingerprint,
    currentFingerprint: afterVerification.currentFingerprint,
    verifiedFingerprint: afterVerification.verifiedFingerprint,
    localCommit: committed.commit,
  };
}

const packageRoot = fileURLToPath(new URL("../../", import.meta.url));
const harnessRoot = path.resolve(process.env.CODEX_REAL_SMOKE_HARNESS_ROOT ?? "/home/zyc14588/deepseek-harness");
const credentialSource = path.resolve(process.env.CODEX_REAL_SMOKE_CREDENTIALS ?? path.join(os.homedir(), ".dsh", ".credentials.yaml"));
const evidencePath = process.env.CODEX_REAL_SMOKE_EVIDENCE_PATH
  ? path.resolve(process.env.CODEX_REAL_SMOKE_EVIDENCE_PATH)
  : undefined;
const keepRoot = process.env.CODEX_REAL_SMOKE_KEEP_ROOT === "1";
const temp = await mkdtemp(path.join(os.tmpdir(), "codex-harness-real-provider-"));
const dshHome = path.join(temp, "dsh-home");
const credentialCopy = path.join(dshHome, ".credentials.yaml");
const repo = path.join(temp, "smoke-repo");
const stateRoot = path.join(temp, "state");
const configPath = path.join(temp, "config.json");
const priorConfig = process.env.CODEX_HARNESS_CONFIG;
const priorDshHome = process.env.DSH_HOME;
const priorBaseUrl = process.env.DEEPSEEK_BASE_URL;
let monitorStarted = false;
let report: Payload = { result: "FAIL", version: "0.6.5", tempRoot: temp };

try {
  const credentialInfo = await stat(credentialSource);
  assert.ok(credentialInfo.isFile(), "real DeepSeek credential source is not a regular file");
  await mkdir(dshHome, { recursive: true, mode: 0o700 });
  await copyFile(credentialSource, credentialCopy);
  await chmod(credentialCopy, 0o600);

  const harnessCommit = await git(harnessRoot, ["rev-parse", "HEAD"]);
  assert.equal(harnessCommit, "141eb6fef83422698aef7a981029e843e8161534");
  assert.equal(await git(harnessRoot, ["status", "--porcelain=v1", "--untracked-files=no"]), "");
  const harnessCli = path.join(harnessRoot, "apps", "cli", "lib", "bin.js");
  const harnessBuildRoot = path.dirname(harnessCli);
  const harnessBuildSha256 = await sha256PathTree(harnessBuildRoot);
  const monitorPort = await reserveLoopbackPort();

  await mkdir(repo, { recursive: true });
  const seed = "real-provider-multiturn-seed-2026-08-22\n";
  await writeFile(path.join(repo, "README.md"), seed, { mode: 0o644 });
  await git(repo, ["init", "-q"]);
  await git(repo, ["config", "user.email", "real-provider-smoke@example.invalid"]);
  await git(repo, ["config", "user.name", "Real Provider Smoke"]);
  await git(repo, ["add", "README.md"]);
  await git(repo, ["commit", "-qm", "fixture: real Provider smoke base"]);
  const mainHeadBefore = await git(repo, ["rev-parse", "HEAD"]);

  await writeFile(configPath, `${JSON.stringify({
    schemaVersion: 6,
    harnessRoot,
    harnessCli,
    harnessBuildRoot,
    harnessProfile: "headless",
    harnessMinimalProfile: "codex-minimal-headless",
    dshHome,
    stateRoot,
    allowedRepoRoots: [temp],
    defaultRuntimeSeconds: 600,
    maxRuntimeSeconds: 900,
    logTailChars: 80_000,
    pinnedHarnessCommit: harnessCommit,
    pinnedHarnessBuildSha256: harnessBuildSha256,
    enforceHarnessPin: true,
    enforceHarnessBuildHash: true,
    requireCleanRepoAtStart: true,
    allowDirtyHarnessCheckout: false,
    controller: { requirePlan: true, preferMinimalHarness: true, splitMemory: { enabled: true, minSamplesForEnforcement: 1 } },
    monitor: {
      enabled: true,
      host: "127.0.0.1",
      port: monitorPort,
      autoStart: true,
      charsPerEstimatedToken: 4,
      pricingAsOf: "real smoke local estimate",
      pricing: {},
      currency: { primary: "CNY", showUsd: false, usdToCnyRate: null, fxAsOf: "not-configured", fxSource: "manual" },
    },
    llamaCpp: { enabled: false, fallbackEnabled: false },
  }, null, 2)}\n`, { mode: 0o600 });

  const rendered = await runProcess("python3", [
    path.join(packageRoot, "scripts", "render-minimal-harness.py"),
    "install",
    "--template-root", path.join(packageRoot, "harness", "minimal"),
    "--profile-dir", path.join(dshHome, "profiles", "codex-minimal-headless"),
    "--preset-dir", path.join(dshHome, ".agent-presets", "codex-bridge-minimal"),
    "--runtime", packageRoot,
    "--config", configPath,
    "--node", process.execPath,
  ], { timeoutMs: 30_000, maxCaptureChars: 200_000 });
  assert.equal(rendered.code, 0, rendered.stderr || rendered.stdout);

  process.env.CODEX_HARNESS_CONFIG = configPath;
  process.env.DSH_HOME = dshHome;
  delete process.env.DEEPSEEK_BASE_URL;
  monitorStarted = true;
  const flash = await runLeaf(repo, seed, {
    planId: "stable-real-flash-multiturn-plan",
    leafId: "real-flash-multiturn",
    taskId: "stable-real-flash-multiturn-task",
    model: "deepseek-v4-flash",
    targetPath: "real-flash-multiturn.txt",
    expectedThinking: "disabled",
    minimumRequests: 4,
    minimumToolCalls: 2,
  });
  const pro = await runLeaf(repo, seed, {
    planId: "stable-real-pro-thinking-plan",
    leafId: "real-pro-thinking",
    taskId: "stable-real-pro-thinking-task",
    model: "deepseek-v4-pro",
    targetPath: "real-pro-thinking.txt",
    expectedThinking: "enabled",
    minimumRequests: 2,
    minimumToolCalls: 1,
  });
  const mainHeadAfter = await git(repo, ["rev-parse", "HEAD"]);
  const mainStatus = await git(repo, ["status", "--porcelain=v1"]);
  assert.equal(mainHeadAfter, mainHeadBefore, "smoke adoption commits must remain isolated from main");
  assert.equal(mainStatus, "", "smoke main must remain clean");
  report = {
    result: "PASS",
    version: "0.6.5",
    provider: "DeepSeek real API via credential provider",
    credentialHandling: "copied without inspection to an isolated 0600 DSH_HOME and removed after the run",
    harnessCommit,
    harnessBuildSha256,
    flash,
    pro,
    mainHeadBefore,
    mainHeadAfter,
    mainClean: true,
    pushed: false,
  };
} catch (error) {
  report = {
    ...report,
    result: "FAIL",
    error: error instanceof Error ? error.message : String(error),
  };
  throw error;
} finally {
  if (monitorStarted) {
    try { await monitorStop(); } catch { /* task evidence remains authoritative */ }
  }
  try { await rm(credentialCopy, { force: true }); } catch { /* never preserve the copied credential */ }
  if (evidencePath !== undefined) {
    await mkdir(path.dirname(evidencePath), { recursive: true });
    await writeFile(evidencePath, `${JSON.stringify(report, null, 2)}\n`, { mode: 0o600 });
  }
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
  if (priorConfig === undefined) delete process.env.CODEX_HARNESS_CONFIG;
  else process.env.CODEX_HARNESS_CONFIG = priorConfig;
  if (priorDshHome === undefined) delete process.env.DSH_HOME;
  else process.env.DSH_HOME = priorDshHome;
  if (priorBaseUrl === undefined) delete process.env.DEEPSEEK_BASE_URL;
  else process.env.DEEPSEEK_BASE_URL = priorBaseUrl;
  if (!keepRoot) await rm(temp, { recursive: true, force: true });
}
