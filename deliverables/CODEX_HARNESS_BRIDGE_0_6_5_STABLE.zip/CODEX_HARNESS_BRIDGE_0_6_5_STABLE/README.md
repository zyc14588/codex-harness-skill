# Codex ↔ DeepSeek Harness Bridge 0.6.5

```text
Version: 0.6.5
Release status: stable
Controlled use allowed: true
Deliverable status: DELIVERABLE_PASS
```

这是一个由 Codex 总控的本地 MCP Bridge。Codex 冻结计划、依赖、精确写租约、Token 门禁、审查与验证；DeepSeek Harness 或受控 llama.cpp 只执行独立叶子。Bridge 不自动 merge、push、tag 或创建 GitHub Release。

## 0.6.5 的关键修复

- 保留已通过真实验证的 managed minimal 五层工具目录、native `bash`/`str_replace_editor`、首轮 mutation 强制、精确租约、Git/scope/review/verification/fingerprint 门禁。
- 每个 Harness execution attempt 在进程启动前冻结模型与 Thinking Policy。
- Minimal Flash 全 attempt 固定 `thinking.type=disabled`，Provider wire 全程省略 `reasoning_effort`。
- Pro Thinking 全 attempt 固定 enabled/high，所有请求省略 `tool_choice`。
- Provider 返回的真实 Pro `reasoning_content` 由 Harness 历史原样保存；Bridge 用 SHA-256、UTF-8 长度和 tool-call IDs 验证后续完整回放。
- 模式切换、缺失/空/篡改 replay 在 Provider I/O 和 Token 计量前 fail-closed。
- Provider/thinking/tool/transport/no-effect 故障归入 infrastructure；split-memory schema 4 隔离所有 schema 1–3 污染。
- 省略模型与显式 Flash 共用同一 split-memory key；零样本基础设施画像不改变规模、复杂度或 Token 建议。

## 发布硬门禁

| 门禁 | 结果 |
|---|---|
| 单元/组件回归 | PASS，74/74 |
| direct process acceptance | PASS |
| 动态 managed-profile Flash/Pro | PASS，Flash 4 轮、Pro 3 轮 |
| 缺失 replay 失败注入 | PASS，Provider 0、Token 0/0、split 不变 |
| 真实 Minimal Flash | PASS，单 attempt 7 轮、6 次 native tool call |
| 真实 Pro Thinking | PASS，单 attempt 7 轮、6 次 native tool call、6 条真实 reasoning requirement |
| package acceptance | PASS，安装/升级/回滚/重装/卸载 |
| skill validation | PASS |
| 最终 ZIP 解压复验 | PASS，外部 sidecar 记录归档 SHA-256 与结果 |

真实 evidence 不保存 API key 或 reasoning 正文，只保存必要的请求形状、哈希、长度、工具调用 ID、指纹和清理结果。

## 安装

要求 Node `>=22.12.0`、Git、Python 3、Codex CLI，以及一个干净且可构建的 DeepSeek Harness checkout。先校验包：

```bash
sha256sum -c MANIFEST_SHA256.txt
```

然后按实际仓库范围安装：

```bash
scripts/install.sh \
  --harness-root /home/zyc14588/deepseek-harness \
  --allowed-root /absolute/path/to/your/repositories
```

安装器会事务式写入版本化 runtime、config、Codex skill/MCP 注册以及 Bridge-managed minimal profile/preset。失败时恢复旧 runtime、配置、skill、profile/preset 和先前 monitor 状态。

常用命令：

```bash
~/.local/share/codex-harness-bridge/0.6.5/scripts/doctor.sh
~/.local/share/codex-harness-bridge/0.6.5/scripts/acceptance.sh
~/.local/share/codex-harness-bridge/0.6.5/scripts/monitor.sh status
~/.local/share/codex-harness-bridge/0.6.5/scripts/uninstall.sh
```

卸载只移除活动 MCP/skill/managed profile/preset 并停止 monitor；版本化 runtime、config、state、日志和任务证据保留，便于审计与恢复。

## 受控工作流

```text
controller_split_advice
→ controller_plan_create
→ controller_launch_leaf
→ harness_status
→ harness_collect
→ harness_read_changed_file（每个 changed path）
→ controller_review_task
→ harness_verify
→ reviewed/current/verified fingerprint 一致
→ harness_commit（仅本地隔离分支）
→ controller_finalize_plan
→ harness_cleanup
```

模型用量只有累计 input/output Token 是硬门禁；API 调用次数和金额只作参考告警。runtime timeout、scope、Git、安全、来源和输出形状仍是独立硬门禁。

## 证据与设计文档

- `release-status.json`：机器可读最终状态；
- `VALIDATION_REPORT_ZH.md`：发布验收总报告；
- `docs/08_ROOT_CAUSE_AND_REPAIR_ZH.md`：根因链与最小修复；
- `docs/11_THINKING_POLICY_DESIGN_ZH.md`：Attempt Thinking Policy；
- `docs/12_SPLIT_MEMORY_SCHEMA4_MIGRATION_ZH.md`：schema 4 迁移；
- `docs/15_SOURCE_PROVENANCE_ZH.md`：源码与 Harness provenance；
- `evidence/03_REAL_DEEPSEEK_0_6_5_STABLE_REDACTED.json`：真实双模式 smoke；
- `evidence/04_FAILURE_INJECTION_0_6_5_STABLE.json`：失败注入；
- `evidence/05_PACKAGE_ACCEPTANCE_0_6_5_STABLE.json`：安装/升级/回滚/卸载；
- `evidence/06_SKILL_VALIDATION_0_6_5_STABLE.json`：skill validator；
- `docs/13_STRICT_ACCEPTANCE_PROMPT_ZH.md` 与 `docs/14_FINAL_READ_ONLY_AUDIT_PROMPT_ZH.md`：独立复核提示词。

`evidence/01` 与 `evidence/02` 是 rc.1 的历史失败证据，明确标为 withdrawn；它们保留用于证明本次修复没有覆盖或删除失败记录。
