# 0.6.5 真实 DeepSeek smoke

最终状态：`PASS`。

## 环境

```text
version: 0.6.5
Harness commit: 141eb6fef83422698aef7a981029e843e8161534
Harness build SHA-256: 6a294d72c51e6570852acaf73458cda98f555bd53c9c7ff0b49c568e7cf88a38
Provider: real DeepSeek API
credential copy: isolated 0600, never inspected/logged, removed in finally
```

真实 smoke 在隔离临时 Git 仓库和 DSH_HOME 中运行。每个任务只租约一个目标文件，提示词要求分离读取、写入、验证三个工具步骤；Codex 随后独立 collect、逐文件读取、review、verify、fingerprint、commit、finalize 和 cleanup。

## Minimal Flash

```text
attempts: 1
Provider requests: 7
native tool calls: 6 (bash)
thinking.type every request: disabled
reasoning_effort present: no
minimal force count: 2
changedPaths: [real-flash-multiturn.txt]
review: approved
verification: PASS
fingerprint: c1d5f76ec498680d93163174388aaedaaca4c5c089809ca3f59a50a819ddea26
local commit: 258d4424b83ed3b7969ac3d82aaae1fea8d006db
worktree/branch cleanup: PASS
```

前两次无 diff 请求使用 disabled + required 强制核心 mutation 工具；出现 diff 后恢复完整工具目录并省略 tool choice，但 thinking 始终 disabled。

## Pro Thinking

```text
attempts: 1
Provider requests: 7
native tool calls: 6 (bash)
thinking.type every request: enabled
reasoning_effort every request: high
tool_choice present: no
real reasoning requirements: 6
replay counts: 6, 5, 4, 3, 2, 1
INVALID_REQUEST: none
changedPaths: [real-pro-thinking.txt]
review: approved
verification: PASS
fingerprint: fdf1c035df1ca1196513c9f5c2d99f904c479ad7a3a6b0367251657c50df4ea4
local commit: 735b67089fefae793d56cf6f4edc4c2b7616f214
worktree/branch cleanup: PASS
```

每条 reasoning requirement 来自 Provider 原响应，证据保存 SHA-256、UTF-8 长度和 tool-call IDs，不保存 reasoning 正文。第 7 个请求同时回放前 6 条 requirement。

## Git 与发布边界

smoke main HEAD 前后均为 `721d0e4fcf6ba290c1b1a1d5e2122aa39c17a2db`，状态干净。两个本地提交只存在于隔离任务分支，cleanup 后分支和 worktree 均删除。未 push、未 merge、未 tag。

机器证据：`evidence/03_REAL_DEEPSEEK_0_6_5_STABLE_REDACTED.json`。
