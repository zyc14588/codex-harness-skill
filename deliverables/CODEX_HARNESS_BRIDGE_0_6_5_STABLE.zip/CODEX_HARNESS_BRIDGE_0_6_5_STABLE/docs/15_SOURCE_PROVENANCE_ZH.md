# 0.6.5 源码 provenance

## 恢复链

权威 0.6.4 源码没有单独归档，但本机已安装 runtime 包含完整 `bridge/src`、`bridge/dist` 与 sourcemap。2026-08-22 的只读回收把以下输入固定为独立 Git 初始提交：

```text
installed runtime: /home/zyc14588/.local/share/codex-harness-bridge/0.6.4
recovered runtime tree SHA-256: 555edb6c760d2c30e7e943755b6519c86d6a160c9e04d0aea504ceb7d95c849f
managed profile tree SHA-256: 9143512bb2d6856675e79a9ac360076fe3db4ec6ac38b292e7cd67db60103a0d
managed preset tree SHA-256: 95099e8928f0a1d35413fa94c52667fb2db5267d0f59b6b507743f181db4ba8b
recovery commit: da1cfd2e74980ee325b5f4bfedf361d24c3d0d2c
```

逐文件比较已安装目录与回收副本无差异。0.6.3 的历史源码仅用于差异参考，不是 0.6.5 的实现基线。

## 修复提交链

```text
da1cfd2  exact installed 0.6.4 recovery
b481c79  rc.1 managed minimal tool-plane repair
d30d9ac  withdrawn rc.1 real Provider failure evidence
<stable commit>  immutable attempt policy, replay integrity, schema 4, stable 0.6.5
<evidence commit> final evidence, manifest and package seal
```

最终两个 SHA 在交付侧车与最终回复中给出；本文件保留占位语义而不制造自引用 manifest/commit 哈希。

## 固定 Harness

真实稳定版 smoke 使用：

```text
Harness root: /home/zyc14588/deepseek-harness
commit: 141eb6fef83422698aef7a981029e843e8161534
tracked status: clean
apps/cli/lib tree SHA-256: 6a294d72c51e6570852acaf73458cda98f555bd53c9c7ff0b49c568e7cf88a38
```

安装器对实际部署的 Harness commit 和 build tree SHA-256 都进行固定，并拒绝未授权的 dirty checkout。

## 构建可审计性

- TypeScript 5.8.3；`@types/node` 22.15.0；Node 24.18.0。
- 完整 strict TypeScript 源码与编译后的 JS、`.d.ts`、sourcemap 一并交付。
- 编译依赖不打入发布包；`bridge/node_modules` 和 lockfile 均不存在。
- `MANIFEST_SHA256.txt` 覆盖除自身外的每个普通文件。
- 未自动 merge、push、tag 或创建 GitHub Release。
