# 0.6.5 测试报告

报告状态：`PASS / stable`。

## 回归矩阵

| 层级 | 命令/入口 | 结果 |
|---|---|---|
| strict build + unit/component | `npm run check` | PASS，74/74 |
| split-memory 窄回归 | `node --test dist/test/split-memory.test.js` | PASS，7/7 |
| direct process E2E | `npm run direct-acceptance` | PASS |
| managed profile mock Provider | `node dist/dynamic-profile-fixture.js` | PASS |
| real Provider | `node dist/real-provider-smoke.js` | PASS |
| package | `scripts/package-acceptance.sh` | PASS |
| skill | `quick_validate.py skills/codex-harness` | PASS |

## 74 项回归覆盖

覆盖预算调整与人民币监控、租约与 symlink/gitlink、mutation lock、attempt policy、minimal request 状态、五层工具目录、渐进工具、monitor/process 生命周期、Harness provenance、schema-4 split memory、task ID、usage/cost、reasoning replay、DSML/Markdown/textual/native tool protocol 以及 orphan handling。

关键新增用例：

- Flash 在出现真实 diff 后仍保持 disabled；
- Flash wire 省略 reasoning effort；
- Pro 模式切换和 tool choice 在 Provider 前拒绝；
- Provider reasoning 哈希/长度捕获与全历史 replay；
- 缺失、空、篡改 replay 拒绝；
- Pro 工具响应缺少 reasoning 归为 provider protocol；
- schema 3 污染隔离、默认 Flash key 规范化；
- infrastructure-only 零样本画像不改变候选 Token 基线。

## 动态门禁

动态 fixture 使用真实 pinned Harness 与实际 managed profile/preset，只把外部 Provider 替换为本地可观测 endpoint：

- Flash：4 轮、3 次 native tool call，全部 disabled、无 reasoning effort；
- Pro：3 轮、2 次 native tool call，全部 enabled/high、无 tool choice，回放深度 0/1/2；
- replay 缺失：HTTP 502、`thinking_replay_state`、Provider 0、Token 0/0、split 建议完全不变。

## Package acceptance

九阶段 package gate 验证：fresh transactional install、manifest/permissions、doctor/effective composition、direct/installed acceptance、旧 config schema 4→6、自定义值保留、同版本注册失败回滚、跨版本回滚和 monitor 恢复、稳定版重装、卸载、无 node_modules/symlink 与 JSON/schema 可解析。

真实 Provider 的完整数值见 `docs/10_REAL_DEEPSEEK_SMOKE_ZH.md` 与 `evidence/03_REAL_DEEPSEEK_0_6_5_STABLE_REDACTED.json`。
