# 0.6.5 安装与运维

## 前置条件

- Linux；Node `>=22.12.0`；Git；Python 3；`sha256sum`；
- Codex CLI 可用；
- DeepSeek Harness checkout 干净，CLI 已构建或允许安装器执行 `pnpm run build`；
- DeepSeek 凭据由 Harness 自己的 credential provider 管理；不要写入 Bridge config、日志或证据；
- 至少一个明确的绝对仓库允许根目录。

## 安装前验证

```bash
sha256sum -c MANIFEST_SHA256.txt
node --version
git -C /home/zyc14588/deepseek-harness status --short
```

安装：

```bash
scripts/install.sh \
  --harness-root /home/zyc14588/deepseek-harness \
  --allowed-root /absolute/repository/root
```

若复用已构建的 Harness：

```bash
scripts/install.sh \
  --harness-root /home/zyc14588/deepseek-harness \
  --allowed-root /absolute/repository/root \
  --no-build-harness
```

安装器固定 Harness commit 和 `apps/cli/lib` 树哈希，验证 manifest，事务式安装 runtime、config、skill、MCP、minimal profile/preset 并启动 loopback monitor。任一步失败都会恢复旧安装面与旧 monitor 状态。

## 路径

```text
runtime: ~/.local/share/codex-harness-bridge/0.6.5
config:  ~/.config/codex-harness-bridge/config.json
state:   ~/.local/state/codex-harness-bridge
skill:   $CODEX_HOME/skills/codex-harness
profile: $DSH_HOME/profiles/codex-minimal-headless
preset:  $DSH_HOME/.agent-presets/codex-bridge-minimal
```

## 健康检查与 monitor

```bash
~/.local/share/codex-harness-bridge/0.6.5/scripts/doctor.sh
~/.local/share/codex-harness-bridge/0.6.5/scripts/acceptance.sh
~/.local/share/codex-harness-bridge/0.6.5/scripts/monitor.sh status
~/.local/share/codex-harness-bridge/0.6.5/scripts/monitor.sh snapshot
~/.local/share/codex-harness-bridge/0.6.5/scripts/monitor.sh stop
~/.local/share/codex-harness-bridge/0.6.5/scripts/monitor.sh start
```

默认 dashboard 为 `http://127.0.0.1:43127`，只监听 loopback。人民币为默认显示；金额和 API 次数是参考告警，累计 input/output Token 才是模型用量硬门禁。

## 升级与迁移

Bridge config schema 为 v6。安装器支持旧 schema 4→6，保留自定义 roots、并发、预算、价格和 llama.cpp 参数；显式 CLI 开关优先。安装前的 runtime/config/skill/Codex config/profile/preset 都进入事务备份。

split-memory 使用独立 schema 4。旧 schema 1–3 保留为 legacy 证据但不参与 advice；后续写入时归档。无需手工删除 rc.1 污染。

不要在活动任务期间编辑 config 或 split memory。预算控制请使用 Web/MCP 控制面；调整只影响后续检查，不重写历史 usage。

## 回滚与卸载

同版本覆盖或跨版本升级若在 Codex MCP 注册等后期阶段失败，安装器恢复：

```text
previous runtime
Bridge config
Codex config and skill
managed profile/preset
previous monitor running state
```

卸载：

```bash
~/.local/share/codex-harness-bridge/0.6.5/scripts/uninstall.sh
```

卸载移除活动注册和 managed integration，停止 monitor；保留 runtime、config、state、worktree 日志和证据。要彻底删除这些审计材料必须由操作员另行明确决定。

## 故障处置

- `thinking_policy_state`：模型、thinking 或 effort 与 attempt 冻结策略不一致；不应通过修改请求继续。
- `thinking_replay_state`：历史 assistant tool-call 消息缺失、空或哈希不符；Provider 尚未调用。
- `provider_protocol`：Provider 拒绝协议或 Pro 工具响应缺少真实 reasoning；保存脱敏证据。
- `provider_transport`：网络/连接故障；与 task shape 分离。
- `minimal_tool_plane_composition` / `minimal_tool_serialization_mismatch`：检查五层工具目录和有效 Cordis 组合。
- `no_effect`：有写租约但没有实际 diff；不能作为成功样本。

上述 infrastructure 失败不会缩小 split 建议。先保存证据并修复单一根因，再重跑同一门禁。
