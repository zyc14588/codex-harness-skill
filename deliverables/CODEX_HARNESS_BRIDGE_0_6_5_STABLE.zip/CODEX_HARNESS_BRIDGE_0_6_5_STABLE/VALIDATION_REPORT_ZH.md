# 0.6.5 稳定版验证报告

```text
DELIVERABLE_PASS
Version: 0.6.5
Release status: stable
Controlled use allowed: true
Real Minimal Flash smoke: PASS
Real Pro Thinking smoke: PASS
Failure-injection smoke: PASS
Package acceptance: PASS
Final ZIP unpacked revalidation: PASS
```

## 验证对象

- 完整 TypeScript 源码、编译产物、声明文件和 sourcemap；
- 事务式安装器、doctor、acceptance、monitor 与卸载器；
- Bridge-managed minimal Harness profile/preset；
- Codex controller skill、plugin/MCP 描述、schemas 与文档；
- 脱敏真实 Provider、失败注入、package 和 skill 证据；
- 最终归档 manifest、外部 ZIP SHA-256 与解压后复验 sidecar。

## 结果摘要

| 项目 | 结果 | 核心证据 |
|---|---|---|
| strict TypeScript + tests | PASS | 74/74 |
| direct acceptance | PASS | 计划、并行、工具、Token、split、审查、验证、清理 |
| dynamic Flash | PASS | 4 轮，全部 disabled，无 reasoning effort，3 次 native call |
| dynamic Pro | PASS | 3 轮，全部 enabled/high、无 tool choice，回放深度 0/1/2 |
| failure injection | PASS | `thinking_replay_state`，Provider 0，Token 0/0，split 不变 |
| real Flash | PASS | 7 轮、6 次 native call、精确 diff/审查/验证/本地提交/清理 |
| real Pro | PASS | 7 轮、6 次 native call、6 段真实 reasoning 完整回放 |
| package acceptance | PASS | fresh install、迁移、同/跨版本回滚、重装、卸载、卫生 |
| skill validation | PASS | `Skill is valid!` |
| final ZIP | PASS | 外部 SHA-256、全新目录解压、manifest 与 package gate 复验 |

## 真实 Provider 判定

真实稳定版使用固定 Harness commit `141eb6fef83422698aef7a981029e843e8161534` 和 build tree SHA-256 `6a294d72c51e6570852acaf73458cda98f555bd53c9c7ff0b49c568e7cf88a38`。凭据仅按字节复制到隔离 mode-0600 `DSH_HOME`，未检查或打印内容，运行后副本删除。

Flash 的 7 个 Provider 请求全部为 disabled 且没有 wire `reasoning_effort`。Pro 的 7 个请求全部 enabled/high、无 `tool_choice`；六条 reasoning requirement 的回放次数为 6、5、4、3、2、1，未出现 `INVALID_REQUEST`。

两项任务均只有一个 attempt，changedPaths 精确匹配租约，逐文件 review approved，verification PASS，reviewed/current/verified fingerprint 完全一致，产生隔离本地提交，随后删除 worktree 和分支。smoke main 的 HEAD 前后相同且干净。

## 限制与授权边界

stable/controlled-use 授权不改变产品治理：不自动 merge、push、tag 或发布；每个实际任务仍须独立冻结租约、Token 门禁、review 和 verification。费用是本地估算，不是供应商账单。历史 rc.1 失败证据仍保留且不被本报告覆盖。
